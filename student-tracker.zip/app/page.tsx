"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Search, Download, Plus } from "lucide-react"

interface Student {
  id: number
  status: boolean
  name: string
  program: string
  countryOfOrigin: string
  intakeYear: string
  graduationYear: string
  recordingDate: string
  releaseDate: string
}

const initialStudents: Student[] = [
  {
    id: 1,
    status: true,
    name: "Dhruthy Cauvery",
    program: "DMM",
    countryOfOrigin: "India",
    intakeYear: "",
    graduationYear: "2025",
    recordingDate: "",
    releaseDate: "Thursday, May 8, 2025",
  },
  {
    id: 2,
    status: false,
    name: "Sushil Lukashi",
    program: "DAV",
    countryOfOrigin: "Zambia",
    intakeYear: "",
    graduationYear: "2025",
    recordingDate: "",
    releaseDate: "",
  },
  {
    id: 3,
    status: false,
    name: "Monika vinod Shirke",
    program: "DMM",
    countryOfOrigin: "India",
    intakeYear: "",
    graduationYear: "2025",
    recordingDate: "",
    releaseDate: "Tuesday, June 10, 2025",
  },
  {
    id: 4,
    status: false,
    name: "Loretta Chingandu",
    program: "DMM",
    countryOfOrigin: "Zambia",
    intakeYear: "",
    graduationYear: "2025",
    recordingDate: "",
    releaseDate: "Monday, June 9, 2025",
  },
  {
    id: 5,
    status: true,
    name: "Yehuda Wexler",
    program: "Comp Science",
    countryOfOrigin: "USA/Israel",
    intakeYear: "Fall 2024",
    graduationYear: "2025",
    recordingDate: "",
    releaseDate: "Thursday, May 22, 2025",
  },
  {
    id: 6,
    status: true,
    name: "Lachibe Elijah",
    program: "Cyber Security",
    countryOfOrigin: "Uganda",
    intakeYear: "Spring 2025",
    graduationYear: "2025",
    recordingDate: "",
    releaseDate: "Thursday, June 12, 2025",
  },
  {
    id: 7,
    status: false,
    name: "Mengcan Zhang",
    program: "DMM",
    countryOfOrigin: "China",
    intakeYear: "Fall 2024",
    graduationYear: "",
    recordingDate: "",
    releaseDate: "",
  },
  {
    id: 8,
    status: false,
    name: "Athinatou Adeniji",
    program: "Cyber Security",
    countryOfOrigin: "Ivory Coast",
    intakeYear: "Spring 2025",
    graduationYear: "",
    recordingDate: "",
    releaseDate: "Monday, June 9, 2025",
  },
  {
    id: 9,
    status: false,
    name: "Ranadhir Reddy Punreddy",
    program: "BME",
    countryOfOrigin: "India",
    intakeYear: "",
    graduationYear: "",
    recordingDate: "",
    releaseDate: "Thursday, May 29, 2025",
  },
]

export default function StudentTracker() {
  const [students, setStudents] = useState<Student[]>(initialStudents)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [programFilter, setProgramFilter] = useState<string>("all")
  const [sortBy, setSortBy] = useState<string>("name")
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc")

  const toggleStatus = (id: number) => {
    setStudents(students.map((student) => (student.id === id ? { ...student, status: !student.status } : student)))
  }

  const filteredAndSortedStudents = useMemo(() => {
    const filtered = students.filter((student) => {
      const matchesSearch =
        student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.program.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.countryOfOrigin.toLowerCase().includes(searchTerm.toLowerCase())

      const matchesStatus =
        statusFilter === "all" ||
        (statusFilter === "completed" && student.status) ||
        (statusFilter === "pending" && !student.status)

      const matchesProgram = programFilter === "all" || student.program === programFilter

      return matchesSearch && matchesStatus && matchesProgram
    })

    filtered.sort((a, b) => {
      let aValue = a[sortBy as keyof Student]
      let bValue = b[sortBy as keyof Student]

      if (typeof aValue === "boolean") {
        aValue = aValue ? 1 : 0
        bValue = bValue ? 1 : 0
      }

      if (aValue < bValue) return sortOrder === "asc" ? -1 : 1
      if (aValue > bValue) return sortOrder === "asc" ? 1 : -1
      return 0
    })

    return filtered
  }, [students, searchTerm, statusFilter, programFilter, sortBy, sortOrder])

  const completedCount = students.filter((s) => s.status).length
  const totalCount = students.length

  const uniquePrograms = Array.from(new Set(students.map((s) => s.program)))

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex flex-col space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Voice Of Katz Guests Tracker</h1>
            <p className="text-muted-foreground">Register, Manage and track Guest information and completion status</p>
          </div>
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Add Student
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Students</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalCount}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Completed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{completedCount}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{totalCount - completedCount}</div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filters & Search</CardTitle>
          <CardDescription>Filter and search through student records</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="space-y-2">
              <Label htmlFor="search">Search</Label>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="Search students..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Program</Label>
              <Select value={programFilter} onValueChange={setProgramFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Programs</SelectItem>
                  {uniquePrograms.map((program) => (
                    <SelectItem key={program} value={program}>
                      {program}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Sort By</Label>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Name</SelectItem>
                  <SelectItem value="status">Status</SelectItem>
                  <SelectItem value="program">Program</SelectItem>
                  <SelectItem value="countryOfOrigin">Country</SelectItem>
                  <SelectItem value="graduationYear">Graduation Year</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Order</Label>
              <Select value={sortOrder} onValueChange={(value: "asc" | "desc") => setSortOrder(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="asc">Ascending</SelectItem>
                  <SelectItem value="desc">Descending</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Student Records</CardTitle>
              <CardDescription>
                Showing {filteredAndSortedStudents.length} of {totalCount} students
              </CardDescription>
            </div>
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]">Status</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Program</TableHead>
                  <TableHead>Country</TableHead>
                  <TableHead>Intake Year</TableHead>
                  <TableHead>Graduation</TableHead>
                  <TableHead>Release Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAndSortedStudents.map((student) => (
                  <TableRow key={student.id} className={student.status ? "bg-green-50" : ""}>
                    <TableCell>
                      <Checkbox checked={student.status} onCheckedChange={() => toggleStatus(student.id)} />
                    </TableCell>
                    <TableCell className="font-medium">{student.name}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{student.program}</Badge>
                    </TableCell>
                    <TableCell>{student.countryOfOrigin}</TableCell>
                    <TableCell>{student.intakeYear || "-"}</TableCell>
                    <TableCell>{student.graduationYear || "-"}</TableCell>
                    <TableCell className="text-sm">{student.releaseDate || "-"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
